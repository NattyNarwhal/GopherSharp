# GopherSharp.Server

This is a lightweight Gopher server using parts of the GopherSharp library. It is incredibly simplistic, and probably not very useful.
