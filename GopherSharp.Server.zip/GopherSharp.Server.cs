using System;
using System.IO;
using System.Threading;
using System.Net;
using System.Net.Sockets;
using System.Xml.Serialization;
using System.Collections.Generic;
using GopherSharp;

// this is all terrible and should be done later when I have an epiphany
namespace GopherSharp.Server {
	// TODO: maybe we can split the host server and serving into a
	// seperate lib (for other apps to embed gopher) - not now of course
	public class GopherServer {
		public static void Main(string[] args) {
			GopherServer gs = new GopherServer(); // the constr. does it
		}
		
		// actual code code, loosely adapted off internet
		// socket clients are nice, servers with multithreading are (!)
		private TcpListener srv;
		
		public GopherServer() {
			srv = new TcpListener(IPAddress.Any, 70);
			new Thread(new ThreadStart(Listen)).Start();
		}
		
		private void Listener() {
			srv.Start();
			while (true) {
				TcpClient tc = srv.AcceptTcpClient();
				new Thread(new ParameterizedThreadStart(
					Handler)).Start(tc);
			}
		}
		
		private void Handler(TcpClient tc) {
			using (Stream s = tc.GetStream()) {
				StreamReader r = new StreamReader(s);
				// TODO
			}
		}
	}
	
	// split this into a sep. class soon with other common utils
	public class GopherServerUtils {
		private static void Init() {
			// let's create some simple sites first
			List<GopherItem> lgi = new List<GopherItem>();
			lgi.Add(new GopherItem("iI am a test\tfake\terror.host\t1"));
			lgi.Add(new GopherItem("iI am a second one\tfake\terror.host\t1"));
			
			Serializer(lgi, "hole/index.xml");
		}
		
		public static void Serializer(List<GopherItem> td, string path) {
			XmlSerializer xs = new XmlSerializer(
				typeof(List<GopherItem>));
			// rw as using
			TextWriter tw = new StreamWriter(path);
			xs.Serialize(tw, td);
			tw.Close();
		}
		
		public static List<GopherItem> Deserializer(string path) {
			List<GopherItem> td = new List<GopherItem>();
			XmlSerializer xs = new XmlSerializer(
				typeof(List<GopherItem>));
			TextReader tr = new StreamReader(path);
			td = (List<GopherItem>)xs.Deserialize(tr);
			tr.Close();
			return td;
		}

	}
}
